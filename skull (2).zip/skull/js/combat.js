// ==========================================
// 전투 물리 엔진 및 오브젝트 풀링 (Combat & Physics)
// ==========================================

// 오브젝트 재사용(풀링) 함수 - 메모리 누수 방지
function getObj(arr) {
    let o = arr.find(x => !x.active);
    if (!o) { 
        o = { active: false }; 
        arr.push(o); 
    }
    o.active = true; 
    return o;
}

// 사각형 충돌(AABB) 감지 함수
function overlap(a, b) {
    return a.x < b.x + b.w && 
           a.x + a.w > b.x && 
           a.y < b.y + b.h && 
           a.y + a.h > b.y;
}

// 지형(발판) 충돌 처리 함수
function resolveAABB(e) {
    e.onGround = false; 
    e.riding = null;
    
    for (let t of Game.platforms) {
        // 아래로 떨어지는 중이거나, 얇은 발판을 아래서 위로 통과할 때는 충돌 무시
        if (t.drop && e.vy < 0) continue;
        if (t.drop && (e.y + e.h) > t.y + 10) continue; 

        if (overlap(e, t)) {
            let dx = (e.x + e.w / 2) - (t.x + t.w / 2);
            let dy = (e.y + e.h / 2) - (t.y + t.h / 2);
            let aw = (e.w + t.w) / 2;
            let ah = (e.h + t.h) / 2;

            let wy = aw * dy;
            let hx = ah * dx;

            if (wy > hx) {
                if (wy > -hx) { 
                    e.y = t.y + t.h; 
                    e.vy = 0; 
                } // 바닥 충돌
                else { 
                    e.x = t.x - e.w; 
                    e.vx = 0; 
                } // 왼쪽 벽 충돌
            } else {
                if (wy > -hx) { 
                    e.x = t.x + t.w; 
                    e.vx = 0; 
                } // 오른쪽 벽 충돌
                else { 
                    e.y = t.y - e.h; 
                    e.vy = 0; 
                    e.onGround = true; 
                    e.riding = t; 
                } // 천장(발판 위) 안착
            }
        }
    }
}

// 플레이어 투사체 생성
function spawnBullet(x, y, vx, vy, life, r, sk, dmg) {
    let b = getObj(Game.bullets);
    b.x = x; 
    b.y = y; 
    b.vx = vx; 
    b.vy = vy; 
    b.life = life; 
    b.maxLife = life; 
    b.r = r; 
    b.sk = sk; 
    b.dmg = dmg;
}

// 적 투사체 생성
function spawnEBullet(x, y, vx, vy, life, r, dmg, grav = false, unblockable = false, isArrow = false, isBomb = false) {
    let b = getObj(Game.eBullets);
    b.x = x; 
    b.y = y; 
    b.vx = vx; 
    b.vy = vy; 
    b.life = life; 
    b.r = r; 
    b.dmg = dmg;
    b.grav = grav; 
    b.unblockable = unblockable; 
    b.isArrow = isArrow; 
    b.isBomb = isBomb;
}

// 레이저(필살기 및 보스 패턴) 생성
function spawnLaser(x, y, w, h, life, color, dmg, isPlayer = false, unblockable = false) {
    let l = getObj(Game.lasers);
    l.x = x; 
    l.y = y; 
    l.w = w; 
    l.h = h; 
    l.life = life; 
    l.maxLife = life; 
    l.color = color; 
    l.dmg = dmg;
    l.isPlayer = isPlayer; 
    l.unblockable = unblockable; 
    l.hitTargets = new Set();
}

// 타격 파티클(이펙트) 생성
function addPart(x, y, col, life, size = 3) {
    let p = getObj(Game.parts);
    p.x = x; 
    p.y = y; 
    p.vx = (Math.random() - 0.5) * 8; 
    p.vy = (Math.random() - 0.5) * 8;
    p.col = col; 
    p.life = life; 
    p.ml = life; 
    p.size = size;
}

// 데미지 텍스트 및 UI 텍스트 생성
function addText(x, y, text, color, life, size = 14, vx = 0, vy = 1.5) {
    let t = getObj(Game.texts);
    t.x = x; 
    t.y = y; 
    t.text = text; 
    t.color = color; 
    t.life = life; 
    t.size = size;
    t.vx = vx; 
    t.vy = vy;
}

// 드롭 아이템 생성
function addItem(x, y, w, h, vy, life, type) {
    let i = getObj(Game.items);
    i.x = x; 
    i.y = y; 
    i.w = w; 
    i.h = h; 
    i.vy = vy; 
    i.life = life; 
    i.type = type;
}

// 몬스터 피격 처리 로직
function hitE(e, dmg, facing, isCrit, extraDmg = 0) {
    if (e.dead) return;
    
    let finalDmg = dmg + Math.floor(dmg * extraDmg);
    e.hp -= finalDmg; 
    e.flash = 6;
    
    // 넉백 처리 (보스는 면역)
    if (!e.isBoss) { 
        e.kbT = 10; 
        e.vx = facing * (e.isElite ? 2 : 4); 
    }
    
    // 데미지 텍스트 띄우기
    addText(
        e.x + e.w / 2, 
        e.y - 10, 
        finalDmg.toString(), 
        isCrit ? "#ffcc00" : "#ffffff", 
        40, 
        isCrit ? 24 : 16
    );
    
    // 출혈(파티클) 효과
    for (let i = 0; i < 10; i++) {
        addPart(e.x + e.w / 2, e.y + e.h / 2, "#ff0000", 15, 3);
    }

    // 흡혈 옵션 발동
    if (Game.pLifestealChance > 0 && Math.random() < Game.pLifestealChance && Game.player.hp < Game.pMaxHp) {
        Game.player.hp = Math.min(Game.pMaxHp, Game.player.hp + 2);
        addText(Game.player.x, Game.player.y - 10, "ABSORB", "#00ff00", 30, 12);
    }
    
    // 타격 시 고정 회복 발동
    if (Game.pHealOnHit && Game.player.hp < Game.pMaxHp && Math.random() < 0.1) {
        Game.player.hp = Math.min(Game.pMaxHp, Game.player.hp + 1);
    }

    // 사망 처리
    if (e.hp <= 0) { 
        e.dead = true; 
        e.hp = 0; 
    }
}