function mkP(x, y) {
  return {
    x, y, w: 14, h: 18, vx: 0, vy: 0, onGround: false,
    hp: pMaxHp, maxHp: pMaxHp, facing: 1, atkT: 0, atkAnim: 0, fr: 0, frT: 0,
    jpOld: false, kbT: 0, guarding: false, jumpCount: 0,
    combo: 0, comboT: 0, dashT: 0, dashCD: 0, parryT: 0, plunging: false
  };
}

function mkEnemy(x, y, w) {
  const rand = Math.random(); let type = "melee";
  if (w >= 1) { if (rand < 0.25) type = "ranged_laser"; else if (rand < 0.5) type = "ranged_bullet"; }
  const hp = (15 + w * 10 + (type === "melee" ? 5 : 0)) * 5;
  return {
    x, y, w: 12, h: 16, vx: 0, vy: 0, onGround: false, hp, maxHp: hp, type,
    isBoss: false, facing: 1, fr: 0, frT: 0, flash: 0, sT: 60 + Math.random() * 40, sI: 60,
    atk: 10 + w * 5, pDir: Math.random() < 0.5 ? 1 : -1, pT: 0, dead: false, kbT: 0, 
    warnT: 0, warnData: null, atkAnim: 0, world: w,
  };
}

function mkBoss(x, y, w) {
  const hps = [0, 1500, 2500, 4000, 6000, 9000]; 
  const hp = hps[Math.min(w, 5)]; 
  return {
    x, y, w: 28, h: 36, vx: 0, vy: 0, onGround: false, hp, maxHp: hp, type: "boss",
    isBoss: true, facing: 1, fr: 0, frT: 0, flash: 0, sT: 90, sI: 80, phase: 1,
    mT: 80, ap: 0, atk: 15 + w * 8, dead: false, kbT: 0, warnT: 0, warnData: null, atkAnim: 0, world: w,
  };
}

function calcLaser(startX, startY, height, facing) {
  let minHitDist = levelW;
  for (const t of platforms) {
    if (t.y < startY + height && t.y + t.h > startY) {
      if (facing > 0 && t.x > startX) minHitDist = Math.min(minHitDist, t.x - startX);
      else if (facing < 0 && t.x + t.w < startX) minHitDist = Math.min(minHitDist, startX - (t.x + t.w));
    }
  }
  return { x: facing > 0 ? startX : Math.max(0, startX - minHitDist), w: minHitDist };
}

function takeDmg(d, attacker, unblockable = false) {
  if (!player) return;
  if (player.dashT > 0 || invT > 0) return;

  let dir = player.facing;
  if (attacker) { dir = player.x < attacker.x ? -1 : 1; } else { dir = -player.facing; }

  let variance = 0.8 + Math.random() * 0.4;
  let defMultiplier = 50 / (50 + pBaseDef);
  let finalDmg = Math.floor((d * variance) * defMultiplier);
  if (finalDmg < 1) finalDmg = 1;

  // 1. 패링 (정확한 타이밍): 데미지 무효화 및 MP 증가
  if (player.parryT > 0 && !unblockable) {
    playSfx('parry'); 
    camShake = 20; hitStop = 15; 
    pMp = Math.min(pMaxMp, pMp + 50); // 💡 패링 성공 시 MP 50 대폭 증가
    player.parryT = 0; invT = 40; 
    texts.push({ x: player.x, y: player.y - 20, text: "PARRY! MP+50", color: "#ffee00", life: 50, size: 24 });
    for (let i = 0; i < 15; i++) addPart(player.x + 7, player.y + 9, "#ffee00", 25);
    comboCount += 2; comboTimer = 150;
    if (attacker && attacker.hp !== undefined) { attacker.vx = -dir * (attacker.isBoss ? 3 : 8); attacker.kbT = 30; }
    updateHUD(); return;
  }

  // 2. 가드 (V 유지): 데미지 100% 무효화
  if (player.guarding) {
    if (unblockable) { player.guarding = false; camShake = 10; } 
    else {
      playSfx('hit');
      for (let i = 0; i < 5; i++) addPart(player.x + 7, player.y + 9, "#80d0ff", 15);
      player.vx = dir * 6.5; player.vy = -3.5; player.kbT = 18; invT = 40;
      
      // 💡 가드 시 받는 데미지를 아예 없앰 (0 데미지)
      texts.push({ x: player.x, y: player.y, text: "BLOCK!", color: "#80d0ff", life: 30 }); 
      if (attacker && attacker.hp !== undefined) { attacker.vx = -dir * (attacker.isBoss ? 1.5 : 5); attacker.kbT = 15; }
      updateHUD(); return;
    }
  }

  if (pShield > 0) {
    playSfx('hit');
    if (pShield >= finalDmg) { pShield -= finalDmg; finalDmg = 0; texts.push({ x: player.x, y: player.y - 10, text: `SHIELD!`, color: "#00ccff", life: 40, size: 20 }); } 
    else { finalDmg -= pShield; pShield = 0; }
  }

  if (finalDmg > 0) {
    playSfx('dmg'); 
    player.hp -= finalDmg; invT = 70;
    player.vx = dir * 4.5; player.vy = -4.5; player.kbT = 15; camShake = 15; comboCount = 0; 
    for (let i = 0; i < 10; i++) addPart(player.x + 7, player.y + 9, "#ff2222", 20);
    texts.push({ x: player.x, y: player.y - 10, text: `-${finalDmg}`, color: "#ff2222", life: 40, size: 20 });
  }
  
  if (player.hp <= 0) {
    gs = "dead"; if (score > highScore) { highScore = score; localStorage.setItem("skull_highscore", highScore); }
    showOv("YOU DIED", "스코어: " + score, "최고 스코어: " + highScore, "▶ RETRY");
  }
  updateHUD();
}

function hitE(e, d, dir, isCrit = false) {
  if (e.dead) return;
  e.hp -= d; e.flash = 8; e.vx = dir * (e.isBoss ? 0.5 : 1); e.vy = -2; e.kbT = 18; 
  playSfx('hit'); 
  
  comboCount++; comboTimer = 150; 
  texts.push({ 
    x: e.x + e.w / 2 + (Math.random() - 0.5) * 12, y: e.y - 5, 
    text: isCrit ? `${d} CRIT!` : d.toString(), 
    color: isCrit ? "#ff1100" : (d > pBaseDmg * 1.2 ? "#ffeb3b" : "#ffffff"), 
    life: 35, size: isCrit ? 22 : 14
  });
  if (e.hp <= 0) e.dead = true;
}

function updateBoss(e) {
  const p = player; if (!p) return;
  const isP2 = e.hp < e.maxHp * 0.5;
  e.phase = isP2 ? 2 : 1; e.vy = Math.min(e.vy + GRAV, 14);
  const dx = p.x + p.w / 2 - (e.x + e.w / 2), dy = p.y + p.h / 2 - (e.y + e.h / 2);
  if (!e.warnT && e.atkAnim <= 0) e.facing = dx > 0 ? 1 : -1; 
  
  let currentSpd = isP2 ? 3.8 : 2.5;
  const w = e.world; 
  
  if (e.atkAnim > 0) e.atkAnim--;
  if (e.kbT > 0) { e.kbT--; e.vx *= 0.88; } 
  else if (e.warnT > 0) {
    e.warnT--; e.vx *= 0.8;
    if (e.warnT <= 0) {
      e.atkAnim = 20; 
      const wd = e.warnData; const originX = wd.facing > 0 ? e.x + e.w : e.x;
      const bDmg = e.atk; const spdM = isP2 ? 1.5 : 1; 
      
      if (w === 5 && isP2 && Math.random() < 0.3) { p.vx -= Math.sign(dx) * 8; p.vy = -2; texts.push({ x: p.x, y: p.y, text: "PULLED!", color: "#cc00ff", life: 30 }); }

      if (w === 1) { 
        if (e.ap === 0) { let arc = isP2 ? 3 : 2; for (let s = -arc; s <= arc; s++) eBullets.push({ x: e.x + 14, y: e.y + 18, vx: Math.cos(wd.ang + s * 0.15) * 7 * spdM, vy: Math.sin(wd.ang + s * 0.15) * 7 * spdM, life: 100, r: 4, dmg: bDmg }); } 
        else if (e.ap === 1) { let arc = isP2 ? 4 : 3; for (let s = -arc; s <= arc; s++) eBullets.push({ x: e.x + 14, y: e.y + 18, vx: Math.cos(wd.ang + s * 0.2) * 5 * spdM, vy: Math.sin(wd.ang + s * 0.2) * 5 * spdM, life: 100, r: 4, dmg: bDmg }); } 
        else { let amt = isP2 ? 24 : 16; for (let i = 0; i < amt; i++) eBullets.push({ x: e.x + 14, y: e.y + 18, vx: Math.cos((i * Math.PI) / (amt/2)) * 6 * spdM, vy: Math.sin((i * Math.PI) / (amt/2)) * 6 * spdM, life: 120, r: 5, dmg: bDmg }); }
      } else if (w === 2) { 
        if (e.ap === 0) { let amt = isP2 ? 10 : 6; for (let i = 0; i < amt; i++) eBullets.push({ x: e.x + 14, y: e.y + 18, vx: wd.facing * (3 + i*(isP2?1:1.5)) * spdM, vy: -8, life: 150, r: 5, dmg: bDmg }); } 
        else if (e.ap === 1) { const lBox = calcLaser(originX, e.y + 18, isP2?24:16, wd.facing); lasers.push({ x: lBox.x, y: e.y + 18, w: lBox.w, h: isP2?24:16, life: 18, maxLife: 18, color: "#aa00ff", dmg: Math.floor(bDmg*1.5), unblockable: true }); camShake = 5; } 
        else { const lBox = calcLaser(originX, e.y - 5, isP2?45:30, wd.facing); lasers.push({ x: lBox.x, y: e.y - 5, w: lBox.w, h: isP2?45:30, life: 25, maxLife: 25, color: "#ff0044", dmg: Math.floor(bDmg*1.5), unblockable: true }); camShake = 8; }
      } else if (w === 3) { 
        if (e.ap === 0) {
          const lBox = calcLaser(originX, e.y + 18, 10, wd.facing); lasers.push({ x: lBox.x, y: e.y + 18, w: lBox.w, h: 10, life: 15, maxLife: 15, color: "#ff1111", dmg: Math.floor(bDmg*1.5), unblockable: true });
          let amt = isP2 ? 12 : 8; for (let i = 0; i < amt; i++) eBullets.push({ x: e.x + 14, y: e.y + 18, vx: Math.cos((i * Math.PI) / (amt/2)) * 8 * spdM, vy: Math.sin((i * Math.PI) / (amt/2)) * 8 * spdM, life: 100, r: 4, dmg: bDmg });
        } else if (e.ap === 1) {
          let amt = isP2 ? 12 : 8; for (let i = 0; i < amt; i++) eBullets.push({ x: e.x + 14, y: e.y + 18, vx: Math.cos((i * Math.PI) / (amt/2)) * 4 * spdM, vy: Math.sin((i * Math.PI) / (amt/2)) * 4 * spdM, life: 100, r: 5, dmg: bDmg });
          let upAmt = isP2 ? 8 : 5; for (let i = 0; i < upAmt; i++) eBullets.push({ x: e.x + 14, y: e.y + 18, vx: wd.facing * (4 + i * 1.5) * spdM, vy: -9, life: 120, r: 4, dmg: bDmg });
        } else {
          const lBox1 = calcLaser(originX, e.y + 5, 12, wd.facing); const lBox2 = calcLaser(originX, e.y + 30, 12, wd.facing);
          lasers.push({ x: lBox1.x, y: e.y + 5, w: lBox1.w, h: 12, life: 20, maxLife: 20, color: "#ff0000", dmg: Math.floor(bDmg*1.5), unblockable: true });
          lasers.push({ x: lBox2.x, y: e.y + 30, w: lBox2.w, h: 12, life: 20, maxLife: 20, color: "#ff0000", dmg: Math.floor(bDmg*1.5), unblockable: true });
          let amt = isP2 ? 24 : 16; for (let i = 0; i < amt; i++) eBullets.push({ x: e.x + 14, y: e.y + 18, vx: Math.cos((i * Math.PI) / (amt/2)) * 5 * spdM, vy: Math.sin((i * Math.PI) / (amt/2)) * 5 * spdM, life: 120, r: 5, dmg: bDmg }); camShake = 12;
        }
      } else if (w === 4) { 
        if (e.ap === 0) { let arc = isP2 ? 2 : 1; for (let s = -arc; s <= arc; s++) eBullets.push({ x: e.x + 14, y: e.y + 18, vx: Math.cos(wd.ang + s * 0.1) * 9 * spdM, vy: Math.sin(wd.ang + s * 0.1) * 9 * spdM, life: 120, r: 4, unblockable: false, dmg: bDmg }); } 
        else if (e.ap === 1) { const lBox = calcLaser(originX, e.y + 18, isP2?30:20, wd.facing); lasers.push({ x: lBox.x, y: e.y + 18, w: lBox.w, h: isP2?30:20, life: 15, maxLife: 15, color: "#ffd700", dmg: Math.floor(bDmg*1.5), unblockable: true }); camShake = 6; } 
        else { let amt = isP2 ? 20 : 12; for (let i = 0; i < amt; i++) eBullets.push({ x: e.x + 14, y: e.y + 18, vx: Math.cos((i * Math.PI) / (amt/2)) * 5 * spdM, vy: Math.sin((i * Math.PI) / (amt/2)) * 5 * spdM, life: 100, r: 6, dmg: bDmg }); }
      } else { 
        if (e.ap === 0) { const lBox = calcLaser(originX, e.y + 10, isP2?60:40, wd.facing); lasers.push({ x: lBox.x, y: e.y + 10, w: lBox.w, h: isP2?60:40, life: 30, maxLife: 30, color: "#330066", dmg: Math.floor(bDmg*2), unblockable: true }); camShake = 15; } 
        else if (e.ap === 1) { let amt = isP2 ? 30 : 20; for (let i = 0; i < amt; i++) eBullets.push({ x: e.x + 14, y: e.y + 18, vx: Math.cos((i * Math.PI) / (amt/2)) * 7 * spdM, vy: Math.sin((i * Math.PI) / (amt/2)) * 7 * spdM, life: 150, r: 5, dmg: bDmg }); } 
        else {
          const lBox = calcLaser(originX, e.y + 20, 16, wd.facing); lasers.push({ x: lBox.x, y: e.y + 20, w: lBox.w, h: 16, life: 20, maxLife: 20, color: "#ff00ff", dmg: Math.floor(bDmg*1.5), unblockable: true });
          let arc = isP2 ? 5 : 3; for (let s = -arc; s <= arc; s++) eBullets.push({ x: e.x + 14, y: e.y, vx: Math.cos(wd.ang + s * 0.3) * 6 * spdM, vy: Math.sin(wd.ang + s * 0.3) * 6 * spdM, life: 120, r: 4, dmg: bDmg });
        }
      }
    }
  } else {
    e.mT--; 
    if (e.mT <= 0) { 
      e.mT = isP2 ? 20 : 40; 
      if (Math.abs(dx) > 250) currentSpd *= 2.2; 
      if (e.onGround && dy < -60 && Math.random() < 0.7) { e.vy = -12; } 
      if (w === 2 && isP2 && Math.random() < 0.3) { e.x = p.x - e.facing * 40; e.y = p.y - 10; texts.push({x: e.x, y: e.y, text: "TELEPORT!", color: "#aa00ff", life: 30}); } 
    }
    e.vx = e.facing * currentSpd; 
    e.sT--;
    if (e.sT <= 0) { e.sT = e.sI * (isP2 ? 0.6 : 1); e.ap = Math.floor(Math.random() * (isP2 ? 3 : 2)); e.warnT = isP2 ? 25 : 35; e.warnData = { ang: Math.atan2(dy, dx), facing: e.facing, ap: e.ap }; e.vx = 0; }
  }

  resolveAABB(e); e.x = Math.max(0, Math.min(levelW - e.w, e.x));
  if (invT === 0 && overlap(player, { x: e.x, y: e.y, w: e.w, h: e.h })) takeDmg(e.atk, e);
  if (e.y > CH + 60) e.dead = true;
}